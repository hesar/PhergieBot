<?php

return array(
    'unit'          => 'f',
    'temperature'   => 10.5,
    'weatherReport' =>
        'nick: Weather for Atlanta, GA - Temperature: 51F/10.5C, ' .
        'Humidity: 96%, Conditions: Fog, Updated: 3/27/11 12:52 PM EDT [ ' .
        'http://weather.com/weather/today/USGA0028 ]',
    'response' => array(
        array(
            'isError' => false,
        ),
        array(
            'isError' => false,
        ),
        array(
            'isError' => false,
        ),
    ),
);
