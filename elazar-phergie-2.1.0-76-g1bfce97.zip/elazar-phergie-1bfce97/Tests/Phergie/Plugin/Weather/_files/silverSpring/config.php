<?php

return array(
    'unit'          => 'f',
    'temperature'   => 35,
    'weatherReport' =>
        'nick: Weather for Silver Spring, MD (20904) - '
        . 'Temperature: 95F/35C, Humidity: 23%, Conditions: Fair, Updated: '
        . '7/26/11 6:25 PM EDT [ http://weather.com/weather/today/20904 ]',
    'response' => array(
        array(
            'isError' => false,
        ),
        array(
            'isError' => false,
        ),
        array(
            'isError' => false,
        ),
    ),
);
