<?php

// Autoloader expects class Phergie_Valid_Interface
// And we want to make sure this interface gets loaded, so define it
interface Phergie_Valid_Interface
{
}