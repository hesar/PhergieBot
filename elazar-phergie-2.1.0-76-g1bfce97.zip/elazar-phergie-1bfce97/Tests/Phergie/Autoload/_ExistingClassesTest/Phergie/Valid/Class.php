<?php

// Autoloader expects class Phergie_Valid_Class
// And we want to make sure this class gets loaded, so define it
class Phergie_Valid_Class
{
}