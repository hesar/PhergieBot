<?php

// Autoloader expects class Phergie_Missing_Class
// But we are testing so we want to fail, so we are not declaring it
